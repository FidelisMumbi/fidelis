Set up MySQL and create a database and table.
Install necessary Node.js packages.
Connect to MySQL from your Node.js server.
Modify the server to insert data into the MySQL database.
Step 1: Set Up MySQL
First, make sure you have MySQL installed and running. Then, create a database and table:

// Set up Mysql
"""
-- Create database
CREATE DATABASE orders_db;

-- Use the database
USE orders_db;

-- Create table
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_name TEXT,
    email VARCHAR(255),
    service VARCHAR(255),
    amount DECIMAL(10, 2),
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""
//
Step 2: Install Necessary Node.js Packages
You will need the mysql2 package to connect to MySQL from Node.js, and dotenv to manage environment variables securely.

//bash
npm install express cors mysql2 dotenv


Step 3: Create a .env File
Create a .env file in the root of your project to store your database connection details:

//.env

DB_HOST=localhost
DB_USER=astron
DB_PASSWORD=Aa123456
DB_DATABASE=orders_db